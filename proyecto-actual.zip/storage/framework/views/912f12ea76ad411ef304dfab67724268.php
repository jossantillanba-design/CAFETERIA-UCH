<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Cafetería UCH')); ?> · Comedor UCH</title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/uch-isotipo.svg')); ?>">

    <!-- Fuentes institucionales UCH: Rubik (títulos) y Open Sans (cuerpo) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Rubik:wght@500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<?php
    $esAdmin = request()->is('admin*') && auth()->check() && auth()->user()->rol === 'administrador';
    $esEmpleado = request()->is('empleado*') && auth()->check() && auth()->user()->rol === 'empleado';
    $esOperacion = $esAdmin || $esEmpleado;
?>

<body class="min-h-screen flex flex-col bg-uch-bg font-sans text-uch-text antialiased">
    <?php if($esAdmin): ?>
        <?php if (isset($component)) { $__componentOriginal6274d3e385ed0a7bef7d4381e58c578f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6274d3e385ed0a7bef7d4381e58c578f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6274d3e385ed0a7bef7d4381e58c578f)): ?>
<?php $attributes = $__attributesOriginal6274d3e385ed0a7bef7d4381e58c578f; ?>
<?php unset($__attributesOriginal6274d3e385ed0a7bef7d4381e58c578f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6274d3e385ed0a7bef7d4381e58c578f)): ?>
<?php $component = $__componentOriginal6274d3e385ed0a7bef7d4381e58c578f; ?>
<?php unset($__componentOriginal6274d3e385ed0a7bef7d4381e58c578f); ?>
<?php endif; ?>
    <?php elseif($esEmpleado): ?>
        <?php if (isset($component)) { $__componentOriginal3af859d6c095660ffa30954555be9912 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3af859d6c095660ffa30954555be9912 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.empleado-topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empleado-topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3af859d6c095660ffa30954555be9912)): ?>
<?php $attributes = $__attributesOriginal3af859d6c095660ffa30954555be9912; ?>
<?php unset($__attributesOriginal3af859d6c095660ffa30954555be9912); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3af859d6c095660ffa30954555be9912)): ?>
<?php $component = $__componentOriginal3af859d6c095660ffa30954555be9912; ?>
<?php unset($__componentOriginal3af859d6c095660ffa30954555be9912); ?>
<?php endif; ?>
    <?php else: ?>
        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <main class="flex-1 w-full <?php echo e($esOperacion ? 'pt-16 pl-[76px] lg:pl-[248px]' : 'pt-16'); ?>">
        <?php echo e($slot); ?>

    </main>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /workspaces/CAFETERIA-UCH/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>