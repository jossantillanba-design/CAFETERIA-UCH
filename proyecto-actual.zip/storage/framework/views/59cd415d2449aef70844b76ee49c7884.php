<?php if(auth()->guard()->check()): ?>
    <?php
        $partesNombre = preg_split('/\s+/', trim(Auth::user()->name));
        $iniciales = mb_strtoupper(mb_substr($partesNombre[0] ?? '', 0, 1) . mb_substr($partesNombre[1] ?? '', 0, 1));
        $rolEtiqueta = match (Auth::user()->rol) {
            'cliente' => 'Estudiante',
            'administrador' => 'Administrador',
            'empleado' => 'Empleado',
            default => 'Usuario',
        };
    ?>
<?php endif; ?>

<nav x-data="navUCH()" x-init="init()" class="hasp-navbar">
    <a href="/" class="hasp-nav-brand" aria-label="Inicio GRUPO HASP SERVICE">
        <div class="hasp-brand-icon">☕</div>
        <div class="hasp-brand-text">
            <span class="hasp-brand-name">GRUPO HASP SERVICE</span>
            <span class="hasp-brand-sub">Cafetería UCH · Comedor Universitario</span>
        </div>
    </a>

    <ul class="hasp-nav-links">
        <li><a href="/menu#menus-del-dia" class="<?php echo e(request()->is('menu') ? 'hasp-active' : ''); ?>">Menú del día</a></li>
        <li><a href="/menu#productos">Productos</a></li>
        <li><a href="/mis-pedidos" class="<?php echo e(request()->is('mis-pedidos') ? 'hasp-active' : ''); ?>">Mis pedidos</a></li>
    </ul>

    <div class="hasp-nav-actions">
        <?php if(request()->is('menu')): ?>
            <div class="hasp-search" x-data="{ q: '' }">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','class' => 'hasp-search-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'hasp-search-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <input type="search"
                       x-init="q = window.busquedaMenu || new URLSearchParams(window.location.search).get('buscar') || ''"
                       :value="q"
                       @input="q = $event.target.value; window.busquedaMenu = q; $dispatch('buscar-menu', { value: q })"
                       placeholder="Buscar plato, café o combo..."
                       aria-label="Buscar en el menú">
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
            <?php if(in_array(auth()->user()->rol, ['administrador', 'empleado'], true)): ?>
                <a href="<?php echo e(auth()->user()->rol === 'administrador' ? '/admin/dashboard' : '/empleado/tomar-orden'); ?>"
                   class="hidden md:inline text-sm font-semibold" style="color: var(--hasp-muted)">
                    <?php echo e(auth()->user()->rol === 'administrador' ? 'Panel admin' : 'Panel empleado'); ?>

                </a>
            <?php endif; ?>
        <?php endif; ?>

        <?php if(request()->is('menu')): ?>
            <button type="button" class="hasp-btn-cart" @click="$dispatch('abrir-carrito')" aria-label="Abrir mi carrito">
                🛒 <span class="hidden sm:inline">Mi carrito</span>
                <span class="hasp-cart-badge" x-text="totalItems">0</span>
            </button>
        <?php else: ?>
            <a href="/checkout" class="hasp-btn-cart" aria-label="Ir a mi pedido">
                🛒 <span class="hidden sm:inline">Mi carrito</span>
                <span class="hasp-cart-badge" x-text="totalItems">0</span>
            </a>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
            <div class="hidden sm:block relative" x-data="{ abierto: false }">
                <button @click="abierto = !abierto" @click.outside="abierto = false" class="flex items-center gap-2" aria-label="Menú de usuario">
                    <span class="hasp-avatar"><?php echo e($iniciales); ?></span>
                </button>
                <div x-show="abierto" x-cloak
                     x-transition:enter="transition ease-out duration-100"
                     x-transition:enter-start="opacity-0 scale-95"
                     x-transition:enter-end="opacity-100 scale-100"
                     class="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-lg py-2 z-50"
                     style="border: 1px solid var(--hasp-border)">
                    <div class="px-4 py-2 mb-1" style="border-bottom: 1px solid var(--hasp-border)">
                        <p class="text-sm font-bold truncate" style="color: var(--hasp-text)"><?php echo e(Auth::user()->name); ?></p>
                        <p class="text-xs" style="color: var(--hasp-muted)"><?php echo e($rolEtiqueta); ?></p>
                    </div>
                    <a href="/mis-pedidos" class="block px-4 py-2 text-sm hover:bg-[#F9F9F7]" style="color: var(--hasp-text)">Mis pedidos</a>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="block px-4 py-2 text-sm hover:bg-[#F9F9F7]" style="color: var(--hasp-text)">Mi perfil</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-full text-left px-4 py-2 text-sm font-semibold hover:bg-[#F9F9F7]" style="color: var(--hasp-brand)">Cerrar sesión</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <a href="/login" class="hasp-btn-login">Iniciar sesión</a>
        <?php endif; ?>

        <button @click="open = !open" class="sm:hidden w-9 h-9 flex items-center justify-center rounded-lg" style="color: var(--hasp-text)" aria-label="Abrir menú">
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'menu','class' => 'w-5 h-5','xShow' => '!open','xCloak' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','class' => 'w-5 h-5','x-show' => '!open','x-cloak' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'close','class' => 'w-5 h-5','xShow' => 'open','xCloak' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close','class' => 'w-5 h-5','x-show' => 'open','x-cloak' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        </button>
    </div>

    <!-- Panel móvil -->
    <div x-show="open" x-cloak class="sm:hidden absolute top-full inset-x-0 bg-white px-4 pb-4 pt-2 shadow-lg" style="border-bottom: 1px solid var(--hasp-border)">
        <div class="flex flex-col gap-1">
            <?php if(request()->is('menu')): ?>
                <div class="relative mb-2" x-data="{ q: '' }">
                    <input type="search"
                           x-init="q = window.busquedaMenu || new URLSearchParams(window.location.search).get('buscar') || ''"
                           :value="q"
                           @input="q = $event.target.value; window.busquedaMenu = q; $dispatch('buscar-menu', { value: q })"
                           placeholder="Buscar plato, café o combo..."
                           aria-label="Buscar en el menú"
                           class="w-full px-4 py-2 rounded-full text-sm" style="border: 1px solid var(--hasp-border); background: var(--hasp-bg)">
                </div>
            <?php endif; ?>
            <a href="/menu#menus-del-dia" @click="open = false" class="px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-text)">Menú del día</a>
            <a href="/menu#productos" @click="open = false" class="px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-text)">Productos</a>
            <a href="/mis-pedidos" @click="open = false" class="px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-text)">Mis pedidos</a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(in_array(auth()->user()->rol, ['administrador', 'empleado'], true)): ?>
                    <a href="<?php echo e(auth()->user()->rol === 'administrador' ? '/admin/dashboard' : '/empleado/tomar-orden'); ?>" @click="open = false" class="px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-text)"><?php echo e(auth()->user()->rol === 'administrador' ? 'Panel admin' : 'Panel empleado'); ?></a>
                <?php endif; ?>
                <a href="<?php echo e(route('profile.edit')); ?>" @click="open = false" class="px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-text)">Mi perfil</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-brand)">Cerrar sesión</button>
                </form>
            <?php else: ?>
                <a href="/login" @click="open = false" class="px-3 py-2 rounded-lg text-sm font-semibold" style="color: var(--hasp-brand)">Iniciar sesión</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<script>
    function navUCH() {
        return {
            open: false,
            items: [],

            get totalItems() {
                return this.items.reduce((suma, item) => suma + (Number(item.cantidad) || 0), 0);
            },

            init() {
                this.items = this.leerCarrito();

                window.addEventListener('carrito-actualizado', (evento) => {
                    this.items = evento.detail || [];
                });
            },

            leerCarrito() {
                try {
                    return JSON.parse(localStorage.getItem('carrito') || '[]');
                } catch (error) {
                    return [];
                }
            },
        };
    }
</script>
<?php /**PATH /workspaces/CAFETERIA-UCH/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>